import mysql.connector
from mysql.connector import Error

class AuthTbl:
    def __init__(self):
        try:
            self.db = mysql.connector.connect(
                host="localhost",
                user="root",
                passwd="hyuck0606",
                port=3306,
                database="fitnessgo"
            )
            # ✔ FIX: dictionary=True so fetchone() returns dict instead of tuple
            self.cursor = self.db.cursor(dictionary=True)
            print("Connected to MySQL successfully!")
        except Error as e:
            print(f"Error connecting to MySQL: {e}")
            self.db = None
            self.cursor = None

    def login(self, username, password):
        if self.db is None:
            return None

        try:
            sql = """
                SELECT UserId
                FROM data_db 
                WHERE BINARY Username = %s 
                AND BINARY Password = %s 
                LIMIT 1
            """
            self.cursor.execute(sql, (username, password))
            result = self.cursor.fetchone()

            if result is None:
                return None

            # ✔ Now works because result is a dictionary
            return result["UserId"]

        except Error as e:
            print("Login error:", e)
            return None

    def insert_info(
            self, username, email, password, fullname, age, gender, height,
            weight, goal, activity, desired_weight, has_health_condition,
            specific_condition=None, photo_bytes=None
    ):
        if self.db is None:
            raise ConnectionError("Database not connected")

        if has_health_condition != "Yes":
            specific_condition = None

        # BMI
        height_m = float(height) / 100
        weight = float(weight)
        bmi = round(weight / (height_m * height_m), 2)

        # BMR (Harris–Benedict)
        if gender.lower() == "male":
            bmr = 88.362 + (13.397 * weight) + (4.799 * float(height)) - (5.677 * age)
        else:
            bmr = 447.593 + (9.247 * weight) + (3.098 * float(height)) - (4.330 * age)

        # Activity factor
        activity_factor = {
            "Low": 1.2,
            "Moderate": 1.55,
            "Active": 1.725,
            "Very Active": 1.9,
        }.get(activity, 1.2)

        # Compute TDEE
        tdee = bmr * activity_factor

        # --- NEW DAILY NET GOAL LOGIC (With Muscle Gain) ---
        if goal == "Lose Weight":
            daily_goal = int(tdee - 500)  # deficit
        elif goal == "Gain Weight":
            daily_goal = int(tdee + 500)  # surplus for bulk
        elif goal == "Gain Muscles":
            daily_goal = int(tdee + 300)  # smaller surplus for lean muscle gain
        else:  # Maintain Weight
            daily_goal = int(tdee)

        # Make sure it doesn’t go below safe limit
        daily_goal = max(daily_goal, 1200)

        sql = """
            INSERT INTO data_db 
            (Username, Email, Password, Fullname, Age, Gender, Height, Weight,
             ActivityLevel, Goal, DesiredWeight, HasHealthConditions,
             WhatHealthConditions, Photo, BMI, DailyNetGoal, Created_at, Updated_at)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, NOW(), NOW())
        """

        values = (
            username, email, password, fullname, age, gender, height, weight,
            activity, goal, desired_weight, has_health_condition,
            specific_condition, photo_bytes, bmi, daily_goal
        )

        try:
            self.cursor.execute(sql, values)
            self.db.commit()

            user_id = self.cursor.lastrowid
            print("USER INSERTED → ID:", user_id)

            return user_id, bmi, daily_goal

        except Error as e:
            self.db.rollback()
            print("INSERT ERROR:", e)
            raise

    def update_photo(self, user_id, photo_bytes):
        try:
            sql = "UPDATE data_db SET Photo = %s WHERE UserId = %s"
            self.cursor.execute(sql, (photo_bytes, user_id))
            self.db.commit()
            print("PHOTO SAVED!")
            return True
        except Error as e:
            print("Photo update error:", e)
            return False

    def get_bmi_and_daily_goal(self, user_id):
        try:
            sql = "SELECT BMI, DailyNetGoal FROM data_db WHERE UserId = %s"
            self.cursor.execute(sql, (user_id,))
            result = self.cursor.fetchone()

            if result:
                # ✔ result is dict now
                return result["BMI"], result["DailyNetGoal"]
            else:
                return None, None

        except Error as e:
            print("Fetch error:", e)
            return None, None

    def get_user_fullname(self, user_id):
        try:
            sql = "SELECT Fullname FROM data_db WHERE UserId = %s LIMIT 1"
            self.cursor.execute(sql, (user_id,))
            result = self.cursor.fetchone()

            if result:
                return result["Fullname"]
            return None
        except Error as e:
            print("Error fetching fullname:", e)
            return None


# Create global instance
auth_tbl = AuthTbl()
