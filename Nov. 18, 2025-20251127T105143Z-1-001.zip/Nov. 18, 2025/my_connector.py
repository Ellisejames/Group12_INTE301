import mysql.connector
from mysql.connector import Error

class AuthTbl:
    def __init__(self):
        try:
            self.db = mysql.connector.connect(
                host="localhost",
                user="root",
                passwd="020820@Steph",
                port=3306,
                database="fitnessgo"
            )
            self.cursor = self.db.cursor()
            print("Connected to MySQL successfully!")
        except Error as e:
            print(f"Error connecting to MySQL: {e}")
            self.db = None
            self.cursor = None

    def insert_info(
        self, username, email, password, fullname, age, gender, height,
        weight, goal, activity, desired_weight, has_health_condition,
        specific_condition=None, photo_bytes=None
    ):
        if self.db is None:
            raise ConnectionError("Database not connected")

        if has_health_condition != "Yes":
            specific_condition = None

        # BMI
        height_m = float(height) / 100
        weight = float(weight)
        bmi = round(weight / (height_m * height_m), 2)

        # BMR
        if gender.lower() == "male":
            bmr = 88.362 + (13.397 * weight) + (4.799 * float(height)) - (5.677 * age)
        else:
            bmr = 447.593 + (9.247 * weight) + (3.098 * float(height)) - (4.330 * age)

        activity_factor = {
            "Low": 1.2, "Moderate": 1.55, "Active": 1.725, "Very Active": 1.9
        }.get(activity, 1.2)

        # ✔ DAILY NET GOAL (with health condition adjustment)
        daily_goal = bmr * activity_factor

        if has_health_condition == "Yes":
            daily_goal *= 0.90  # reduce by 10%

        daily_goal = int(daily_goal)

        sql = """
            INSERT INTO data_db 
            (Username, Email, Password, Fullname, Age, Gender, Height, Weight,
             ActivityLevel, Goal, DesiredWeight, HasHealthConditions,
             WhatHealthConditions, Photo, BMI, DailyNetGoal, Created_at, Updated_at)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, NOW(), NOW())
        """

        values = (
            username, email, password, fullname, age, gender, height, weight,
            activity, goal, desired_weight, has_health_condition,
            specific_condition, photo_bytes, bmi, daily_goal
        )

        try:
            self.cursor.execute(sql, values)
            self.db.commit()

            user_id = self.cursor.lastrowid
            print("USER INSERTED → ID:", user_id)

            return user_id, bmi, daily_goal

        except Error as e:
            self.db.rollback()
            print("INSERT ERROR:", e)
            raise

    def update_photo(self, user_id, photo_bytes):
        try:
            sql = "UPDATE data_db SET Photo = %s WHERE UserId = %s"
            self.cursor.execute(sql, (photo_bytes, user_id))
            self.db.commit()
            print("PHOTO SAVED!")
            return True
        except Error as e:
            print("Photo update error:", e)
            return False

    def get_bmi_and_daily_goal(self, user_id):
        """Fetch BMI and DailyNetGoal from the database."""
        try:
            sql = "SELECT BMI, DailyNetGoal FROM data_db WHERE UserId = %s"
            self.cursor.execute(sql, (user_id,))
            result = self.cursor.fetchone()

            if result:
                return result[0], result[1]
            else:
                return None, None

        except Error as e:
            print("Fetch error:", e)
            return None, None


auth_tbl = AuthTbl()
