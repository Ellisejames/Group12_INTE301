from kivy.clock import Clock
from kivy.animation import Animation
from kivymd.app import MDApp
from kivy.lang import Builder
from kivymd.uix.screen import MDScreen
from kivymd.uix.screenmanager import MDScreenManager
from kivymd.uix.snackbar import MDSnackbar, MDSnackbarText
from kivy.properties import BooleanProperty, ListProperty
from kivy.properties import StringProperty
from PIL import Image as PILImage, ImageOps, ImageDraw
from plyer import filechooser
from kivy.core.window import Window
from kivy.core.image import Image as CoreImage
import io

from my_connector import auth_tbl


Window.borderless = True
Window.size = (380, 650)


class WelcomeScreen(MDScreen):
    pass


class ButtonScreen(MDScreen):
    pass


class loginScreen(MDScreen):
    def show_msg(self, message):
        MDSnackbar(
            MDSnackbarText(text=message),
            pos_hint={"center_x": 0.5, "center_y": 0.1},
            size_hint_x=0.8,
        ).open()

    def login_user(self):
        username = self.ids.username_field.text.strip()
        password = self.ids.password_field.text.strip()

        if not username or not password:
            self.show_msg("Please enter username and password")
            return

        user_id = auth_tbl.login(username, password)

        if user_id:
            self.show_msg("Login Successful!")

            next_screen = self.manager.get_screen("signup_screen7")
            next_screen.user_id = user_id

            self.manager.transition.direction = "left"
            self.manager.current = "signup_screen7"
        else:
            self.show_msg("Invalid username or password")


class signupScreen(MDScreen):
    selected_gender = StringProperty("")  # "Male" or "Female"

    def validate_and_continue(self):
        if self.validate_fields():
            # Save inputs
            sm_data = self.manager.user_data
            sm_data['fullname'] = self.ids.fullname_field.text.strip()
            sm_data['age'] = int(self.ids.age_field.text.strip())
            sm_data['weight'] = float(self.ids.weight_field.text.strip())
            sm_data['height'] = float(self.ids.height_field.text.strip())
            sm_data['gender'] = self.selected_gender

            self.manager.transition.direction = "fade"
            self.manager.current = "signup_screen2"

    def validate_fields(self):
        """Validate fields: show specific messages if one empty/invalid, generic if multiple empty"""
        fullname = self.ids.fullname_field.text.strip()
        age = self.ids.age_field.text.strip()
        weight = self.ids.weight_field.text.strip()
        height = self.ids.height_field.text.strip()
        gender = self.selected_gender

        # Collect empty fields
        empty_fields = []
        if not fullname:
            empty_fields.append("Full name")
        if not age:
            empty_fields.append("Age")
        if not weight:
            empty_fields.append("Weight")
        if not height:
            empty_fields.append("Height")
        if not gender:
            empty_fields.append("Gender")

        # If multiple fields empty, show generic message
        if len(empty_fields) > 1:
            self.show_snackbar("Please fill out all fields.")
            return False
        # If exactly one field empty, show specific message
        elif len(empty_fields) == 1:
            self.show_snackbar(f"{empty_fields[0]} is required.")
            return False

        # Validate age (integer)
        if not age.isdigit():
            self.show_snackbar("Age must be a valid integer.")
            return False

        # Validate weight and height (float)
        if not self.is_float(weight):
            self.show_snackbar("Weight must be a valid number.")
            return False
        if not self.is_float(height):
            self.show_snackbar("Height must be a valid number.")
            return False

        return True

    @staticmethod
    def is_float(value):
        try:
            float(value)
            return True
        except ValueError:
            return False

    def show_snackbar(self, text):
        snack = MDSnackbar(
            MDSnackbarText(
                text=text,
                halign="center",
                valign="middle",
                theme_text_color="Custom",
                text_color=(1, 1, 1, 1),
                font_size="16sp",
            ),
            duration=2,
            size_hint=(0.9, None),
            height="40dp",
            pos_hint={"center_x": 0.5, "y": 0.05},
            md_bg_color=(0.8, 0.1, 0.1, 1),  # red color
            radius=[20, 20, 20, 20],
        )
        snack.open()


class signupScreen2(MDScreen):
    selected_activitylevel = StringProperty("")

    def validate_and_continue(self):
        if self.validate_fields():
            # Save activity level
            self.manager.user_data['activity_level'] = self.selected_activitylevel

            self.manager.transition.direction = "fade"
            self.manager.current = "signup_screen3"

    def validate_fields(self):
        if not self.selected_activitylevel:
            self.show_snackbar("Please select an activity level.")
            return False
        return True

    def show_snackbar(self, text):
        snack = MDSnackbar(
            MDSnackbarText(
                text=text,
                halign="center",  # horizontal center
                valign="middle",  # vertical center
                theme_text_color="Custom",
                text_color=(1, 1, 1, 1),
                font_size="16sp",
            ),
            duration=2,
            size_hint=(0.9, None),
            height="40dp",
            pos_hint={"center_x": 0.5, "y": 0.05},
            md_bg_color=(0.1, 0.5, 0.1, 1),
            radius=[20, 20, 20, 20],
        )
        snack.open()


class signupScreen3(MDScreen):
    selected_goal = StringProperty("")

    def validate_and_continue(self):
        desired_weight = self.ids.desired_weight_input.text.strip()

        if not self.selected_goal:
            self.show_snackbar("Please select your goal.")
            return
        if not desired_weight:
            self.show_snackbar("Desired weight is required.")
            return

        try:
            desired_weight_value = float(desired_weight)
            if desired_weight_value <= 0:
                self.show_snackbar("Please enter a valid desired weight.")
                return
        except ValueError:
            self.show_snackbar("Desired weight must be a number.")
            return

        # Save inputs
        sm_data = self.manager.user_data
        sm_data['goal'] = self.selected_goal
        sm_data['desired_weight'] = desired_weight_value

        self.manager.transition.direction = "fade"
        self.manager.current = "signup_screen4"

    def show_snackbar(self, text):
        snack = MDSnackbar(
            MDSnackbarText(
                text=text,
                halign="center",
                valign="middle",
                theme_text_color="Custom",
                text_color=(1, 1, 1, 1),
                font_size="16sp",
            ),
            duration=2,
            size_hint=(0.9, None),
            height="40dp",
            pos_hint={"center_x": 0.5, "y": 0.05},
            md_bg_color=(0.8, 0.1, 0.1, 1),  # red color for errors
            radius=[20, 20, 20, 20],
        )
        snack.open()


class signupScreen4(MDScreen):
    selected_healthconditions = ListProperty([])
    show_other_field = BooleanProperty(False)
    selected_boolean_healthcondition = StringProperty("")  # "Yes" or "No"

    def toggle_condition(self, condition_name, button):
        """
        Toggle a health condition in selected_healthconditions list
        and update button color. Show 'Other' input if condition_name == 'Others'.
        """
        if condition_name in self.selected_healthconditions:
            self.selected_healthconditions.remove(condition_name)
            button.md_bg_color = (0.7, 0.7, 0.7, 1)  # gray = unselected
            if condition_name == "Others":
                self.show_other_field = False
        else:
            self.selected_healthconditions.append(condition_name)
            button.md_bg_color = (0, 0.7, 0, 1)  # green = selected
            if condition_name == "Others":
                self.show_other_field = True

    def select_health_condition(self, value):
        """Call this from KV buttons to update selection"""
        self.selected_boolean_healthcondition = value
        if value == "Yes":
            self.show_other_field = True
        else:
            self.show_other_field = False
            self.selected_healthconditions.clear()

    def validate_and_continue(self):
        sm_data = self.manager.user_data

        if self.selected_boolean_healthcondition not in ["Yes", "No"]:
            self.show_snackbar("Please select Yes or No for health conditions.")
            return

        sm_data['has_health_condition'] = self.selected_boolean_healthcondition

        if self.selected_boolean_healthcondition == "Yes":
            if not self.selected_healthconditions:
                self.show_snackbar("Please select at least one health condition.")
                return

            # Build final condition list
            conditions = list(self.selected_healthconditions)

            if "Others" in conditions:
                other_text = self.ids.other_condition_input.text.strip()
                if other_text:
                    conditions.remove("Others")
                    conditions.append(other_text)
                else:
                    self.show_snackbar("Please specify your other health condition.")
                    return

            sm_data['specific_condition'] = ", ".join(conditions)
        else:
            self.selected_healthconditions.clear()
            sm_data['specific_condition'] = None

        print("Selected Health Condition:", sm_data['has_health_condition'])
        print("Specific Conditions:", sm_data.get('specific_condition'))

        self.manager.transition.direction = "fade"
        self.manager.current = "signup_screen5"

    def show_snackbar(self, text):
        snack = MDSnackbar(
            MDSnackbarText(
                text=text,
                halign="center",
                valign="middle",
                theme_text_color="Custom",
                text_color=(1, 1, 1, 1),
                font_size="16sp",
            ),
            duration=2,
            size_hint=(0.9, None),
            height="40dp",
            pos_hint={"center_x": 0.5, "y": 0.05},
            md_bg_color=(0.8, 0.1, 0.1, 1),
            radius=[20, 20, 20, 20],
        )
        snack.open()






class signupScreen5(MDScreen):
    """
    Last signup screen that validates input fields and saves all user data
    from signup_screen up to signup_screen5 into the database.
    """

    def validate_and_create_account(self):
        if not self.validate_fields():
            return

        sm_data = self.manager.user_data

        # Add signupScreen5 fields
        sm_data['username'] = self.ids.username_field.text.strip()
        sm_data['email'] = self.ids.email_field.text.strip()
        sm_data['password'] = self.ids.password_field.text.strip()

        # Insert into database
        try:
            has_health_condition = sm_data.get('has_health_condition', 'No')  # already "Yes" or "No"

            user_id = auth_tbl.insert_info(
                username=sm_data.get('username', 'N/A'),
                email=sm_data.get('email', 'N/A'),
                password=sm_data.get('password', 'N/A'),
                fullname=sm_data.get('fullname', 'N/A'),
                age=sm_data.get('age', 0),
                gender=sm_data.get('gender', 'N/A'),
                height=sm_data.get('height', 0.0),
                weight=sm_data.get('weight', 0.0),
                goal=sm_data.get('goal', 'Maintain'),
                activity=sm_data.get('activity_level', 'Low'),
                desired_weight=sm_data.get('desired_weight', sm_data.get('weight', 0.0)),
                has_health_condition=has_health_condition,
                specific_condition=sm_data.get('specific_condition', None),
                photo_bytes = sm_data.get('photo_bytes', None)
            )

            # ✅ Save user_id in the ScreenManager so other screens can access it
            self.manager.created_user_id = user_id

            self.show_snackbar(f"Account created successfully! ", success=True)
            self.manager.user_data = {}  # clear after insert
            self.manager.transition.direction = "fade"
            self.manager.current = "signup_screen6"

        except Exception as e:
            self.show_snackbar(f"Failed to create account ", success=False)

    def validate_fields(self):
        username = self.ids.username_field.text.strip()
        email = self.ids.email_field.text.strip()
        password = self.ids.password_field.text.strip()
        con_password = self.ids.con_password_field.text.strip()

        empty_fields = []
        if not username:
            empty_fields.append("Username")
        if not email:
            empty_fields.append("Email")
        if not password:
            empty_fields.append("Password")
        if not con_password:
            empty_fields.append("Confirm Password")

        if len(empty_fields) > 1:
            self.show_snackbar("Please fill out all fields.", success=False)
            return False
        if len(empty_fields) == 1:
            self.show_snackbar(f"{empty_fields[0]} is required.", success=False)
            return False

        if "@" not in email or "." not in email:
            self.show_snackbar("Please enter a valid email address.", success=False)
            return False

        if len(password) < 6:
            self.show_snackbar("Password must be at least 6 characters.", success=False)
            return False
        if password != con_password:
            self.show_snackbar("Passwords do not match.", success=False)
            return False

        return True

    def show_snackbar(self, text, success=True):
        color = (0.1, 0.6, 0.1, 1) if success else (0.8, 0.1, 0.1, 1)
        snack = MDSnackbar(
            MDSnackbarText(
                text=text,
                halign="center",
                valign="middle",
                theme_text_color="Custom",
                text_color=(1, 1, 1, 1),
                font_size="16sp",
            ),
            duration=3,
            size_hint=(0.9, None),
            height="40dp",
            pos_hint={"center_x": 0.5, "y": 0.05},
            md_bg_color=color,
            radius=[20, 20, 20, 20],
        )
        snack.open()




class signupScreen6(MDScreen):

    selected_image_path = StringProperty(None)
    photo_bytes = None
    user_id = None

    # ---------------------------------------
    # Load passed user_id from signupScreen5
    # ---------------------------------------
    def on_pre_enter(self, *args):
        uid = getattr(self.manager, "created_user_id", None)
        if isinstance(uid, tuple):
            self.user_id = uid[0]
        else:
            self.user_id = uid
        print("SIGNUP6 — Loaded User ID:", self.user_id)

        if not self.user_id:
            self.show_snackbar("ERROR: User ID missing!", success=False)

    # ---------------------------------------
    # Convert image → circular PNG bytes
    # ---------------------------------------
    def make_image_circle(self, path):
        img = PILImage.open(path).convert("RGBA")
        size = min(img.size)

        img = ImageOps.fit(img, (size, size))

        mask = PILImage.new("L", (size, size), 0)
        draw = ImageDraw.Draw(mask)
        draw.ellipse((0, 0, size, size), fill=255)
        img.putalpha(mask)

        buffer = io.BytesIO()
        img.save(buffer, format="PNG")
        buffer.seek(0)

        return buffer

    # ---------------------------------------
    # File Picker
    # ---------------------------------------
    def open_file_manager(self):
        filechooser.open_file(on_selection=self.on_file_select)

    def on_file_select(self, selection):
        if not selection:
            return

        path = selection[0]
        self.selected_image_path = path

        buffer = self.make_image_circle(path)

        # Show preview
        self.ids.profile_img.texture = CoreImage(buffer, ext="png").texture

        # Save PNG bytes
        self.photo_bytes = buffer.getvalue()

        self.show_snackbar("Profile picture selected!", success=True)

    # ---------------------------------------
    # Save photo to DB
    # ---------------------------------------
    def save_profile_photo(self):
        from my_connector import auth_tbl

        if not self.photo_bytes:
            self.show_snackbar("Please select a photo first.", success=False)
            return

        if not self.user_id:
            self.show_snackbar("User ID missing!", success=False)
            return

        success = auth_tbl.update_photo(self.user_id, self.photo_bytes)

        if success:
            self.show_snackbar("Photo saved successfully!", success=True)
            next_screen = self.manager.get_screen("signup_screen7")
            next_screen.set_user_id(self.user_id)
            self.manager.current = "signup_screen7"  # Only switch if successful

        else:
            self.show_snackbar("Failed to upload photo.", success=False)

    def skip_photo(self):
        """User chooses Not Now — still pass the user_id to next screen."""
        if not self.user_id:
            self.show_snackbar("User ID missing!", success=False)
            return

        next_screen = self.manager.get_screen("signup_screen7")
        next_screen.set_user_id(self.user_id)
        self.manager.current = "signup_screen7"

    # ---------------------------------------
    # Snackbar
    # ---------------------------------------
    def show_snackbar(self, text, success=True):
        color = (0.1, 0.6, 0.1, 1) if success else (0.85, 0.1, 0.1, 1)

        snack = MDSnackbar(
            MDSnackbarText(
                text=text,
                halign="center",
                valign="middle",
                theme_text_color="Custom",
                text_color=(1, 1, 1, 1),
                font_size="16sp",
            ),
            duration=2,
            size_hint=(0.9, None),
            height="40dp",
            pos_hint={"center_x": 0.5, "y": 0.05},
            md_bg_color=color,
            radius=[20, 20, 20, 20],
        )
        snack.open()



class SignupScreen7(MDScreen):
    user_id = None  # will be set by previous screen

    def set_user_id(self, user_id):
        """Called by previous screen to pass the new user ID."""
        self.user_id = user_id

    def on_pre_enter(self, *args):
        """When screen opens, load BMI & daily goal from database."""
        if self.user_id is not None:
            self.load_bmi_and_goal()
        else:
            self.ids.dailycaloriegoal_message.text = "No user ID"
            self.ids.bmi_message.text = "No user ID"
            self.ids.bmi_status.text = "User not detected"

    def load_bmi_and_goal(self):
        """Fetch BMI and daily goal for this user from the database."""
        try:
            bmi, daily_goal = auth_tbl.get_bmi_and_daily_goal(self.user_id)

            if bmi is None or daily_goal is None:
                self.ids.dailycaloriegoal_message.text = "N/A"
                self.ids.bmi_message.text = "N/A"
                self.ids.bmi_status.text = "Error loading data"
                return

            # Display values
            self.ids.dailycaloriegoal_message.text = f"{daily_goal} Calories"
            self.ids.bmi_message.text = str(bmi)

            # BMI Category
            if bmi < 18.5:
                status = "Underweight"
            elif bmi < 25:
                status = "Normal"
            elif bmi < 30:
                status = "Overweight"
            else:
                status = "Obese"

            self.ids.bmi_status.text = status

        except Exception as e:
            self.ids.dailycaloriegoal_message.text = "Error"
            self.ids.bmi_message.text = "Error"
            self.ids.bmi_status.text = str(e)

    def show_snackbar(self, text, success=True):
        color = (0.1, 0.6, 0.1, 1) if success else (0.8, 0.1, 0.1, 1)

        snack = MDSnackbar(
            MDSnackbarText(
                text=text,
                halign="center",
                valign="middle",
                theme_text_color="Custom",
                text_color=(1, 1, 1, 1),
                font_size="16sp",
            ),
            duration=2,
            size_hint=(0.9, None),
            height="40dp",
            pos_hint={"center_x": 0.5, "y": 0.05},
            md_bg_color=color,
            radius=[20, 20, 20, 20],
        )
        snack.open()




class dashboardScreen(MDScreen):
    pass


class WindowManager(MDScreenManager):
    class WindowManager(MDScreenManager):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self.user_data = {}


class FitnessApp(MDApp):

    def build(self):
        self.title = "Fitness Go"
        self.icon = "logo.png"
        self.theme_cls.primary_palette = "Green"
        self.theme_cls.theme_style = "Light"


        root = Builder.load_file("fitness.kv")
        root.opacity = 0
        return root

    def show_snackbar(self, text):
        """Reusable Snackbar"""
        MDSnackbar(
            text=text,
            md_bg_color=(0.1, 0.5, 0.1, 1),
            duration=2,
        ).open()

    def on_start(self):
        root = self.root

        fade_in = Animation(opacity=1, duration=1)
        fade_in.start(root)

        welcome = root.get_screen("welcome_screen")
        welcome.ids.indicator.start()

        Clock.schedule_once(self.stop_loading_indicator, 1)

    def stop_loading_indicator(self, dt):
        welcome = self.root.get_screen("welcome_screen")
        welcome.ids.indicator.stop()
        Clock.schedule_once(self.fade_out_welcome, 1)

    def fade_out_welcome(self, dt):
        welcome = self.root.get_screen("welcome_screen")
        anim = Animation(opacity=0, duration=1)
        anim.bind(on_complete=lambda *x: self.switch_to_button_screen())
        anim.start(welcome)

    def switch_to_button_screen(self):
        self.root.current = "button_screen"
        screen = self.root.get_screen("button_screen")
        screen.opacity = 0
        Animation(opacity=1, duration=1).start(screen)

    def signup_user(self):
        pass



if __name__ == "__main__":
    FitnessApp().run()
